from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='rspmm',
    ext_modules=[
        CUDAExtension('rspmm', [
            'source/rspmm.cpp',
            'source/rspmm.cu',
        ]),
    ],
    cmdclass={
        'build_ext': BuildExtension
    })